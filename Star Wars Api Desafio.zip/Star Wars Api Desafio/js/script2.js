let btn = document.querySelector('#btn')
let name = document.querySelector('#name')
let population = document.querySelector('#population')
let climate = document.querySelector('#climate')
let terrain = document.querySelector('#terrain')
let gravity = document.querySelector('#gravity')
let diameter = document.querySelector('#diameter')

function getData() {
    generateDataLoading()
    let randomPlanets = Math.floor((Math.random() * 61) + 1)
    let swApi = "https://swapi.co/api/planets/" + randomPlanets
    

    axios.get(swApi).then(response => {
        generateData(response.data)
    }).catch(e => {
        generateDataFail()
    })
}
function generateData(data) {
    name.innerText = data.name
    population.innerText = data.population
    climate.innerText = data.climate
    terrain.innerText = data.terrain
    gravity.innerText = data.gravity
    diameter.innerText = data.diameter
    
    
}
function generateDataFail() {
    name.innerText = 'Ops! Cadê?'
    population.innerText = ''
    climate.innerText = ''
    terrain.innerText = '' 
    gravity.innerText = ''
    diameter.innerText = ''
    
}
function generateDataLoading() {
    name.innerHTML = '<i class="fas fa-circle-notch fa-spin fa-sw"></i>'
    population.innerText = ''
    climate.innerText = ''
    terrain.innerText = '' 
    gravity.innerText = ''
    diameter.innerText = ''
}
next.addEventListener('click', getData)


