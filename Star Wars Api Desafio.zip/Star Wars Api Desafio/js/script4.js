let btn = document.querySelector('#btn')
let name = document.querySelector('#name')
let model = document.querySelector('#model')
let starship_class = document.querySelector('#starship_class')
let length = document.querySelector('#length')
let MGLT = document.querySelector('#MGLT')
let cargo_capacity = document.querySelector('#cargo_capacity')

function getData() {
    generateDataLoading()
    let randomStarships = Math.floor((Math.random() * 61) + 1)
    let swApi = "https://swapi.co/api/starships/" + randomStarships
    

    axios.get(swApi).then(response => {
        generateData(response.data)
    }).catch(e => {
        generateDataFail()
    })
}
function generateData(data) {
    name.innerText = data.name
    model.innerText = data.model
    starship_class.innerText = data.starship_class
    length.innerText = data.length
    MGLT.innerText = data.MGLT
    cargo_capacity.innerText = data.cargo_capacity
    
    
}
function generateDataFail() {
    name.innerText = 'Ops! Cadê?'
    model.innerText = ''
    starship_class.innerText = ''
    length.innerText = '' 
    MGLT.innerText = ''
    cargo_capacity.innerText = ''
    
}
function generateDataLoading() {
    name.innerHTML = '<i class="fas fa-circle-notch fa-spin fa-sw"></i>'
    model.innerText = ''
    starship_class.innerText = ''
    length.innerText = '' 
    MGLT.innerText = ''
    cargo_capacity.innerText = ''
}
next.addEventListener('click', getData)


