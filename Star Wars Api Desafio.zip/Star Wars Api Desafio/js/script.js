let btn = document.querySelector('#btn')
let name = document.querySelector('#name')
let birth_year = document.querySelector('#birth_year')
let eye_color = document.querySelector('#eye_color')
let gender = document.querySelector('#gender')
let height = document.querySelector('#height')
let skin_color = document.querySelector('#skin_color')
let mass = document.querySelector('#mass')

function getData() {
    generateDataLoading()
    let randomPeople = Math.floor((Math.random() * 61) + 1)
    let swApi = "https://swapi.co/api/people/" + randomPeople
    

    axios.get(swApi).then(response => {
        generateData(response.data)
    }).catch(e => {
        generateDataFail()
    })
}
function generateData(data) {
    name.innerText = data.name
    birth_year.innerText = data.birth_year
    eye_color.innerText = data.eye_color
    gender.innerText = data.gender
    height.innerText = data.height
    skin_color.innerText = data.skin_color
    mass.innerText = data.mass
    
}
function generateDataFail() {
    name.innerText = 'Ops! Cadê?'
    birth_year.innerText = ''
    eye_color.innerText = ''
    gender.innerText = '' 
    height.innerText = ''
    skin_color.innerText = ''  
    mass.innerText = '' 
}
function generateDataLoading() {
    name.innerHTML = '<i class="fas fa-circle-notch fa-spin fa-sw"></i>'
    birth_year.innerText = ''
    eye_color.innerText = ''
    gender.innerText = ''
    height.innerText = ''
    skin_color.innerText = ''
    mass.innerText = ''
}
next.addEventListener('click', getData)


