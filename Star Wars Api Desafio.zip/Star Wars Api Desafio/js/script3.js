let btn = document.querySelector('#btn')
let name = document.querySelector('#name')
let model = document.querySelector('#model')
let vehicle_class = document.querySelector('#vehicle_class')
let manufacturer = document.querySelector('#manufacturer')
let crew = document.querySelector('#crew')
let max_atmosphering_speed = document.querySelector('#max_atmosphering_speed')

function getData() {
    generateDataLoading()
    let randomVehicles = Math.floor((Math.random() * 61) + 1)
    let swApi = "https://swapi.co/api/vehicles/" + randomVehicles
    

    axios.get(swApi).then(response => {
        generateData(response.data)
    }).catch(e => {
        generateDataFail()
    })
}
function generateData(data) {
    name.innerText = data.name
    model.innerText = data.model
    vehicle_class.innerText = data.vehicle_class
    manufacturer.innerText = data.manufacturer
    crew.innerText = data.crew
    max_atmosphering_speed.innerText = data.max_atmosphering_speed
    
    
}
function generateDataFail() {
    name.innerText = 'Ops! Cadê?'
    model.innerText = ''
    vehicle_class.innerText = ''
    manufacturer.innerText = '' 
    crew.innerText = ''
    max_atmosphering_speed.innerText = ''
    
}
function generateDataLoading() {
    name.innerHTML = '<i class="fas fa-circle-notch fa-spin fa-sw"></i>'
    model.innerText = ''
    vehicle_class.innerText = ''
    manufacturer.innerText = '' 
    crew.innerText = ''
    max_atmosphering_speed.innerText = ''
}
next.addEventListener('click', getData)


